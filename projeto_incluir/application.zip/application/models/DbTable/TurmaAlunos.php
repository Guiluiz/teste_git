<?php

class Application_Model_DbTable_TurmaAlunos extends Zend_Db_Table_Abstract
{

    protected $_name = 'turma_alunos';


}

