<?php

class Application_Model_DbTable_Turma extends Zend_Db_Table_Abstract
{

    protected $_name = 'turma';


}

