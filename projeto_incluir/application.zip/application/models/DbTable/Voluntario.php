<?php

class Application_Model_DbTable_Voluntario extends Zend_Db_Table_Abstract
{

    protected $_name = 'voluntario';


}

