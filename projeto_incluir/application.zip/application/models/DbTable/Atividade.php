<?php

class Application_Model_DbTable_Atividade extends Zend_Db_Table_Abstract
{

    protected $_name = 'atividade';


}

