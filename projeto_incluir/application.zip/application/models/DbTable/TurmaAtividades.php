<?php

class Application_Model_DbTable_TurmaAtividades extends Zend_Db_Table_Abstract
{

    protected $_name = 'turma_atividades';


}

