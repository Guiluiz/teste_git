<?php

class Application_Model_DbTable_Disciplina extends Zend_Db_Table_Abstract {

    protected $_name = 'disciplina';
}

