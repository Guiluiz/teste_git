<?php

class Application_Model_DbTable_NotasAlunos extends Zend_Db_Table_Abstract
{

    protected $_name = 'nota_aluno';


}

