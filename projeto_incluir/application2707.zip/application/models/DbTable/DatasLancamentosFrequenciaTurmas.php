<?php

class Application_Model_DbTable_DatasLancamentosFrequenciaTurmas extends Zend_Db_Table_Abstract
{

    protected $_name = 'datas_lancamentos_frequencias_turmas';


}

