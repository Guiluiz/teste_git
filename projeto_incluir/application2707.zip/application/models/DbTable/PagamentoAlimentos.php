<?php

class Application_Model_DbTable_PagamentoAlimentos extends Zend_Db_Table_Abstract
{

    protected $_name = 'pagamento_alimentos';


}

