<?php

class Application_Model_DbTable_DisciplinaPreRequisitos extends Zend_Db_Table_Abstract {

    protected $_name = 'disciplina_pre_requisitos';
    
}

?>
