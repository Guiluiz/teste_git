<?php

class Application_Model_DbTable_VoluntarioTurmas extends Zend_Db_Table_Abstract
{

    protected $_name = 'voluntario_turmas';


}

