<?php

class Application_Model_DbTable_DatasAtividade extends Zend_Db_Table_Abstract {

    protected $_name = 'datas_funcionamento';

}
