<?php

class Application_Model_DbTable_VoluntarioDisciplinas extends Zend_Db_Table_Abstract
{

    protected $_name = 'voluntario_disciplinas';


}

